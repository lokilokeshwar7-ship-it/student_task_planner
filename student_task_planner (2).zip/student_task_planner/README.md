# Student Task Planner

A small beginner-friendly web project built with HTML, CSS, and JavaScript.

## Features
- Add student tasks
- Mark tasks as completed or pending
- Filter all, pending, and completed tasks
- Delete tasks
- Save tasks in the browser using `localStorage`
- Responsive layout for mobile and desktop

## Run locally
1. Download or extract the project folder.
2. Open `index.html` in a modern browser.
3. Add a few sample tasks and test the filters.

## GitHub upload
1. Create a new repository on GitHub, for example `student-task-planner`.
2. Keep it Public if you need to share the link with your instructor.
3. Choose **Add file → Upload files**.
4. Upload `index.html` and `README.md`.
5. Click **Commit changes**.
6. Open the repository page and copy its URL.

## Before presenting
Understand how the form, task array, `localStorage`, filters, and completion checkbox work. Customize the title or styling and be transparent that this is a mini project/template you adapted.
